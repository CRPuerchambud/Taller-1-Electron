/**
 * © 2017 Liferay, Inc. <https://liferay.com>
 *
 * SPDX-License-Identifier: MIT
 */

'use strict';

const gulp = require('gulp');
const cleanCSS = require('gulp-clean-css');
const concat = require('gulp-concat');
const uglify = require('gulp-uglify');
const liferayThemeTasks = require('liferay-theme-tasks');


liferayThemeTasks.registerTasks({
	gulp,
	hookFn: function(gulp) {
	     gulp.hook('before:build:war', function(done) {
	    	 
	      function minifyJS(){
	    	  gulp.src('./build/js/*.js')
		      .pipe(uglify())
		      .pipe(gulp.dest('./build/js'))
		      .on('end', done);  
	      }
	      
	      function minifyCSS(){
	    	  gulp.src('./build/css/*.css')
	    	    .pipe(cleanCSS({compatibility: 'ie8'}))
	    	    .pipe(gulp.dest('./build/css/'))
	    	    .on('end', minifyJS);
	      }
	    	 
	      gulp.src(['./build/css/main.css'])
    	     .pipe(concat("main.css"))
    	     .pipe(gulp.dest('./build/css/'))
    	    .on('end', minifyCSS);
	      
	     });
	   }
});